//61720435
interface Printer {
	default void print(int i) {}
}
