//61720435
public class Vertex {
	void draw(Turtle t) {
	
	}
}
