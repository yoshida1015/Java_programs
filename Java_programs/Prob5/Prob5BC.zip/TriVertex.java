//61720435
public class TriVertex extends Vertex{
	void draw(Turtle t) {
		t.penDown();
		t.go(10);
		t.rotate(240);
		t.go(10);
		t.rotate(240);
		t.go(10);
		t.rotate(240);
		}
}
