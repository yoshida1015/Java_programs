//61720435
public class CrossVertex extends Vertex{
	void draw(Turtle t) {
		t.penDown();
		t.go(10);
		t.rotate(180);
		t.go(10);
		t.rotate(90);
		t.go(10);
		t.rotate(180);
		t.go(10);
		t.rotate(90);
		t.go(10);
		t.rotate(180);
		t.go(10);
		t.rotate(90);
		t.go(10);
		t.rotate(180);
		t.go(10);
		t.rotate(90);
	}
}
